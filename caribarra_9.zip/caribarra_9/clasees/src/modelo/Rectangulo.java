
package modelo;

public class Rectangulo extends FiguraGeometrica {
    private double altura ; 
    private double base ;
    
     public Rectangulo(double base, double altura) {
         this.base = base ; 
         this.altura = altura ; 
         this.nombre = "Rectángulo";
         
     }
     @Override
    public double calcularArea() {
        return base * altura;
    
}
}
