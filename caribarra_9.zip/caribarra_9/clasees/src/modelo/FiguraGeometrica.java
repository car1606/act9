
package modelo;

/**
 *
 * @author Administrador
 */
     public abstract class FiguraGeometrica {
    protected String nombre; 
    
    public FiguraGeometrica() {
       
    }

    public void setNombre(String nombre) {
        this.nombre = nombre; 
    }

    public String getNombre() {
        return nombre;
    }
    public abstract double calcularArea(); // Método abstracto

    public void mostrarInfo() { // Método concreto (heredado)
        System.out.println("Figura: " + nombre);
    }
   }

