
package modelo;


public class principal {
   
            public static void main(String[] args) {
        FiguraGeometrica circulo = new Circulo(5);
        FiguraGeometrica rectangulo = new Rectangulo(4, 6);
        FiguraGeometrica triangulo = new Triangulo(3, 5);

        circulo.mostrarInfo();
        System.out.println("Área: " + circulo.calcularArea());

        rectangulo.mostrarInfo();
        System.out.println("Área: " + rectangulo.calcularArea());

        triangulo.mostrarInfo();
        System.out.println("Área: " + triangulo.calcularArea());
    }
}

